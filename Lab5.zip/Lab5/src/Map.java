import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Optional;
import java.util.Scanner;

public class Map {

    /**
     * This method saves to file a rectangular block of text (representing a map in PA1) based on the given dimensions.
     * Before saving the map, print out the number of rows on the first line, the number of columns on the second line,
     * and the actual block of text starting from the third line.
     *
     * @param filename The filename to save the block of text. Assume it includes the .txt extension.
     * @param map      The grid of chars to save
     * @throws IllegalArgumentException If # of rows < 3 or # cols < 3
     */
    public void createMap(String filename, char[][] map) throws IllegalArgumentException {
        //TODO
    }

    /**
     * Loads a map into a 2d char array. Note that the format of the text file will be the same
     * format as we saved it: first row  has an integer representing how many rows, second row has an integer
     * representing how many columns, and the rest of the rows is the actual block of text.
     *
     * @param filename The filename of the map
     * @param minRows  the minimum number of rows this map must have. If violated, throw BadMapException
     * @param minCols  the minimum number of cols this map must have. If violated, throw BadMapException
     * @return The 2d char representing the map.
     * @throws BadMapException if the minRows or minCols constraints are violated.
     */
    public char[][] loadMap(String filename, int minRows, int minCols) throws BadMapException {
        //TODO
        return null; //You may also need to change this statement
    }


}
