module lab8_GUI {
        requires javafx.controls;
        requires javafx.media;
        exports lab8;
}