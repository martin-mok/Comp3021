
public class Teacher extends Person {
    private String subject;
    private double salary;

    //TODO
}
