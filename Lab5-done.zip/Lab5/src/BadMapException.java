public class BadMapException extends Exception {
}
