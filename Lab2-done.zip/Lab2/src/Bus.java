public class Bus {
    private int busID;
    private String model;

    public Bus(int busID, String model){
        this.busID=busID;
        this.model=model;
    }
    public int getID() {
        return busID;
    }

}
