import java.util.Arrays;
import java.util.Objects;

public class BusCompany {
    private String name;

    BusCompany(String name) {
        this.name = name;
        numCompanies++;
    }

}