public class Bus {
    private int busID;

    public int getID() {
        return busID;
    }

}
