import java.math.BigInteger;

/**
 * TODO 1:
 * Create an abstract class "Expression". It has exactly one public abstract method, eval(), which returns a BigInteger
 * object.
 */

public abstract class Expression {
    public abstract BigInteger eval();
}
