package Map;

/**
 * A class representing a solid wall.
 */
public class Wall extends Cell {

    @Override
    public char getRepresentation() {
        return '#';
    }
}
